import numpy as np
import math

def f(x):
	return math.cos(x)

a=input("Rango inicial de la funcion: ")
b=input("Rango final de la funcion: ")
n=input("Numero de particiones: ")
x=np.arange(int(a), int(b), float(float(int(b)-int(a))/int(n)))

deltax=float(float(int(b)-int(a))/float(n))


t=0.0

for i in range(1,len(x)):
	integral=float(float(int(b)-int(a))/float(n))*(f(int(a)+(i-1/2)*float(float(int(b)-int(a))/float(n))))
	t=t+integral

print("La integral es: ",t)

