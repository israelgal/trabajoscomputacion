import numpy as np
import math

def f(x):
	return math.cos(x)

deltax=0.003
a=-1
b=1
x=np.arange(a, b, 0.003)

n=0.0

for i in range(1,len(x)):
	integral=deltax*(f(a+(i-1/2)*deltax))
	n=n+integral

print(n)

