
# coding: utf-8

# In[4]:


import numpy as np
import math 


def factorial(n):
    M=1
    F=1
    while M<int(N):
        M=M+1
        F=F*M
    return (F)

def polinomio(x,n):   
    valorpolinomio=(float(x)**2-1)**float(n)
    return valorpolinomio

def derivada(x,n):
    return ((polinomio(float(x)+h,n))-polinomio(x,n))/h
def segderivada(x,n):
    return (derivada(float(x)+h,n)-derivada(x,n))/h
    
    
h=0.000000000001




#n=2
#x=2
N=input('dame un numero n')
X=input('dame un numero x')
print(factorial(N)) 
print(polinomio(X,N))
print(derivada(X,N))
print(segderivada(X,N))

